
Author: April McBroom
Version: 3.0

Requirement: MongoDB Atlas
credentials: 
Admin: root
password:uhartroot
Database:CRUD
Restrictions:Log from any IP address

Download following required files:
express, dotenv, morgan, body-parser, path (check server.js file)

To start project:
npm start in terminal

