Running Server:
Use npm start as command
Packages: Make sure to install packages from the server.js file with npm install packagename. 
These files will be marked with a require method.

CRUD application for any website or business that supports a user-form. 