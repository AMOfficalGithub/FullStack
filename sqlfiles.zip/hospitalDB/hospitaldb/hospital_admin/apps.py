from django.apps import AppConfig


class HospitalAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hospital_admin'
